import { Scrobble, SamplePreset, PlaqueCertification } from '../types/music';

export const SAMPLE_PRESETS: SamplePreset[] = [
  {
    id: 'cyberpunk-synth',
    name: 'Neo-Tokyo Resonance',
    username: 'kavinsky_drifter',
    tagline: 'Synthwave, Darksynth, French Electro & French Touch',
    avatar: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=150&h=150&fit=crop&q=80',
    tags: ['Synthwave', 'Darksynth', 'Cyberpunk', 'French Electro'],
  },
  {
    id: 'psychedelic-vinyl',
    name: 'Analog Prism Vault',
    username: 'floydian_reverie',
    tagline: '60s & 70s Progressive Rock, Krautrock, Psychedelia & Art Rock',
    avatar: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=150&h=150&fit=crop&q=80',
    tags: ['Prog Rock', 'Psychedelic', 'Space Rock', 'Vinyl Purist'],
  },
  {
    id: 'indie-ethereal',
    name: 'Midnight Reverie',
    username: 'cocteau_echoes',
    tagline: 'Dream Pop, Shoegaze, Post-Punk, Mid-90s Slowcore',
    avatar: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&h=150&fit=crop&q=80',
    tags: ['Dream Pop', 'Shoegaze', 'Post-Punk', 'Ethereal'],
  },
  {
    id: 'jazz-hiphop-crate',
    name: 'Blue Note Crate Diggers',
    username: 'dilla_sp1200',
    tagline: 'Hard Bop, Modal Jazz, Golden Age Hip-Hop & Neo-Soul',
    avatar: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&h=150&fit=crop&q=80',
    tags: ['Jazz Fusion', 'Boom Bap', 'Neo-Soul', 'Sample Archaeology'],
  },
];

interface TrackDef {
  title: string;
  artist: string;
  album: string;
  coverArt: string;
  weight: number;
  variants?: string[];
}

const PRESET_TRACKS: Record<string, TrackDef[]> = {
  'cyberpunk-synth': [
    {
      title: 'Nightcall',
      artist: 'Kavinsky',
      album: 'OutRun',
      coverArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop&q=80',
      weight: 38,
      variants: ['Nightcall (Original)', 'Nightcall - Radio Edit', 'Nightcall (Drive Soundtrack Version)'],
    },
    {
      title: 'Turbo Killer',
      artist: 'Carpenter Brut',
      album: 'Trilogy',
      coverArt: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&h=300&fit=crop&q=80',
      weight: 29,
      variants: ['Turbo Killer (2015 Remaster)', 'Turbo Killer'],
    },
    {
      title: 'Tech Noir',
      artist: 'GUNSHIP',
      album: 'GUNSHIP',
      coverArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&h=300&fit=crop&q=80',
      weight: 24,
    },
    {
      title: 'Resonance',
      artist: 'HOME',
      album: 'Odyssey',
      coverArt: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=300&fit=crop&q=80',
      weight: 35,
      variants: ['Resonance (Slowed)', 'Resonance'],
    },
    {
      title: 'Endless Summer',
      artist: 'The Midnight',
      album: 'Endless Summer',
      coverArt: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&h=300&fit=crop&q=80',
      weight: 26,
    },
    {
      title: 'Sunset',
      artist: 'The Midnight',
      album: 'Endless Summer',
      coverArt: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&h=300&fit=crop&q=80',
      weight: 22,
    },
    {
      title: 'Roller Mobster',
      artist: 'Carpenter Brut',
      album: 'Trilogy',
      coverArt: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&h=300&fit=crop&q=80',
      weight: 20,
    },
    {
      title: 'Genesis',
      artist: 'Justice',
      album: 'Cross (â€ )',
      coverArt: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop&q=80',
      weight: 18,
    },
    {
      title: 'DVNO',
      artist: 'Justice',
      album: 'Cross (â€ )',
      coverArt: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop&q=80',
      weight: 15,
    },
    {
      title: 'Pacific Coast Highway',
      artist: 'Kavinsky',
      album: 'OutRun',
      coverArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop&q=80',
      weight: 16,
    },
  ],
  'psychedelic-vinyl': [
    {
      title: 'Time',
      artist: 'Pink Floyd',
      album: 'The Dark Side of the Moon',
      coverArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop&q=80',
      weight: 42,
      variants: ['Time (2011 Remaster)', 'Time - 2023 50th Anniversary Remaster', 'Time (Live at Wembley 1974)'],
    },
    {
      title: 'Echoes',
      artist: 'Pink Floyd',
      album: 'Meddle',
      coverArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop&q=80',
      weight: 33,
    },
    {
      title: 'Starless',
      artist: 'King Crimson',
      album: 'Red',
      coverArt: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=300&h=300&fit=crop&q=80',
      weight: 30,
      variants: ['Starless - Steven Wilson Mix', 'Starless (2019 Audio)'],
    },
    {
      title: '21st Century Schizoid Man',
      artist: 'King Crimson',
      album: 'In the Court of the Crimson King',
      coverArt: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=300&h=300&fit=crop&q=80',
      weight: 25,
    },
    {
      title: 'Close to the Edge',
      artist: 'Yes',
      album: 'Close to the Edge',
      coverArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop&q=80',
      weight: 22,
    },
    {
      title: 'Roundabout',
      artist: 'Yes',
      album: 'Fragile',
      coverArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop&q=80',
      weight: 24,
      variants: ['Roundabout - 2003 Remaster', 'Roundabout'],
    },
    {
      title: 'Comfortably Numb',
      artist: 'Pink Floyd',
      album: 'The Wall',
      coverArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop&q=80',
      weight: 36,
      variants: ['Comfortably Numb (2011 Remastered)', 'Comfortably Numb - Pulse Live'],
    },
    {
      title: 'Riders on the Storm',
      artist: 'The Doors',
      album: 'L.A. Woman',
      coverArt: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=300&h=300&fit=crop&q=80',
      weight: 20,
    },
  ],
  'indie-ethereal': [
    {
      title: 'Cherry-coloured Funk',
      artist: 'Cocteau Twins',
      album: 'Heaven or Las Vegas',
      coverArt: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop&q=80',
      weight: 40,
      variants: ['Cherry-coloured Funk (Remastered)', 'Cherry-coloured Funk'],
    },
    {
      title: 'Heaven or Las Vegas',
      artist: 'Cocteau Twins',
      album: 'Heaven or Las Vegas',
      coverArt: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop&q=80',
      weight: 34,
    },
    {
      title: 'Alison',
      artist: 'Slowdive',
      album: 'Souvlaki',
      coverArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&h=300&fit=crop&q=80',
      weight: 35,
      variants: ['Alison (2020 Remaster)', 'Alison'],
    },
    {
      title: 'When the Sun Hits',
      artist: 'Slowdive',
      album: 'Souvlaki',
      coverArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&h=300&fit=crop&q=80',
      weight: 31,
    },
    {
      title: 'Only Shallow',
      artist: 'My Bloody Valentine',
      album: 'Loveless',
      coverArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop&q=80',
      weight: 27,
    },
    {
      title: 'Sometimes',
      artist: 'My Bloody Valentine',
      album: 'Loveless',
      coverArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop&q=80',
      weight: 23,
    },
    {
      title: 'Sparks',
      artist: 'Beach House',
      album: 'Depression Cherry',
      coverArt: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=300&fit=crop&q=80',
      weight: 28,
    },
    {
      title: 'Space Song',
      artist: 'Beach House',
      album: 'Depression Cherry',
      coverArt: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=300&fit=crop&q=80',
      weight: 38,
      variants: ['Space Song (2015)', 'Space Song'],
    },
  ],
  'jazz-hiphop-crate': [
    {
      title: 'Time: The Donut of the Heart',
      artist: 'J Dilla',
      album: 'Donuts',
      coverArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop&q=80',
      weight: 45,
      variants: ['Time: The Donut of the Heart (Original)', 'Time: The Donut of the Heart'],
    },
    {
      title: 'Workinonit',
      artist: 'J Dilla',
      album: 'Donuts',
      coverArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop&q=80',
      weight: 32,
    },
    {
      title: 'So What',
      artist: 'Miles Davis',
      album: 'Kind of Blue',
      coverArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop&q=80',
      weight: 39,
      variants: ['So What - 1959 Mono', 'So What (Stereo Remaster)'],
    },
    {
      title: 'Blue in Green',
      artist: 'Miles Davis',
      album: 'Kind of Blue',
      coverArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop&q=80',
      weight: 30,
    },
    {
      title: 'Accordion',
      artist: 'Madvillain',
      album: 'Madvillainy',
      coverArt: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=300&h=300&fit=crop&q=80',
      weight: 36,
    },
    {
      title: 'All Caps',
      artist: 'Madvillain',
      album: 'Madvillainy',
      coverArt: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=300&h=300&fit=crop&q=80',
      weight: 34,
      variants: ['All Caps (Instrumental)', 'All Caps'],
    },
    {
      title: 'A Love Supreme, Pt. 1 - Acknowledgement',
      artist: 'John Coltrane',
      album: 'A Love Supreme',
      coverArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop&q=80',
      weight: 29,
    },
    {
      title: 'Electric Relaxation',
      artist: 'A Tribe Called Quest',
      album: 'Midnight Marauders',
      coverArt: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop&q=80',
      weight: 26,
    },
  ],
};

export function generateSampleScrobbles(presetId: string = 'cyberpunk-synth'): Scrobble[] {
  const trackDefs = PRESET_TRACKS[presetId] || PRESET_TRACKS['cyberpunk-synth'];
  const scrobbles: Scrobble[] = [];

  const nowSeconds = Math.floor(Date.now() / 1000);
  const totalWeeks = 14;
  const totalDays = totalWeeks * 7;
  const startSeconds = nowSeconds - totalDays * 86400;

  let globalId = 1;

  // For each track, create an emergence curve (e.g. debut week, peak week, longevity)
  trackDefs.forEach((def, trackIdx) => {
    // Generate between 35 and 90 scrobbles per track
    const baseCount = Math.max(30, def.weight * 2 + Math.floor(Math.random() * 20));
    
    // Assign a debut week (0 to 8) and a peak week
    const debutWeek = Math.min(totalWeeks - 4, (trackIdx * 2) % (totalWeeks - 3));
    const peakWeek = Math.min(totalWeeks - 1, debutWeek + 1 + Math.floor(Math.random() * 3));

    for (let i = 0; i < baseCount; i++) {
      // Pick a week biased towards debut -> peak -> decay
      let weekTarget = debutWeek + Math.floor(Math.random() * (totalWeeks - debutWeek));
      if (Math.random() < 0.6) {
        // High concentration around peak
        weekTarget = Math.max(debutWeek, Math.min(totalWeeks - 1, peakWeek + Math.floor((Math.random() - 0.4) * 3)));
      }

      const dayInWeek = Math.floor(Math.random() * 7);
      const dayOffset = weekTarget * 7 + dayInWeek;

      // Circadian hour bias: 60% evening/night (18:00 - 03:00)
      let hour: number;
      const roll = Math.random();
      if (roll < 0.6) {
        hour = (18 + Math.floor(Math.random() * 9)) % 24;
      } else if (roll < 0.8) {
        hour = 12 + Math.floor(Math.random() * 6);
      } else {
        hour = 7 + Math.floor(Math.random() * 5);
      }

      const minute = Math.floor(Math.random() * 60);
      const second = Math.floor(Math.random() * 60);
      const timeInDay = hour * 3600 + minute * 60 + second;

      const timestamp = Math.min(nowSeconds - 60, startSeconds + dayOffset * 86400 + timeInDay);

      // Random variant chance if defined
      let chosenTitle = def.title;
      if (def.variants && def.variants.length > 0 && Math.random() < 0.28) {
        chosenTitle = def.variants[Math.floor(Math.random() * def.variants.length)];
      }

      scrobbles.push({
        id: `scrobble_${presetId}_${globalId++}`,
        title: chosenTitle,
        artist: def.artist,
        album: def.album,
        coverArt: def.coverArt,
        timestamp,
      });
    }
  });

  // Sort chronologically descending
  return scrobbles.sort((a, b) => b.timestamp - a.timestamp);
}

export const INITIAL_DEFAULT_PLAQUES: PlaqueCertification[] = [
  {
    id: 'plaque_gold_kavinsky',
    subjectTitle: 'Nightcall',
    subjectSubtitle: 'Kavinsky',
    subjectType: 'track',
    coverArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop&q=80',
    milestone: 'gold',
    threshold: 50,
    scrobblesEarned: 74,
    awardedDate: 'Aug 2026',
    frameStyle: 'classic-walnut',
    customEngraving: 'Presented to commemorate exceeding 50 verified scrobbles in personal listening vault.',
  },
  {
    id: 'plaque_plat_time',
    subjectTitle: 'Time',
    subjectSubtitle: 'Pink Floyd',
    subjectType: 'track',
    coverArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop&q=80',
    milestone: 'platinum',
    threshold: 100,
    scrobblesEarned: 112,
    awardedDate: 'Jul 2026',
    frameStyle: 'platinum-brushed',
    customEngraving: 'Official Platinum Record celebrating 100+ spins of the timeless psychedelic masterpiece.',
  },
  {
    id: 'plaque_diamond_dilla',
    subjectTitle: 'J Dilla',
    subjectSubtitle: 'Career Artist Legacy',
    subjectType: 'artist',
    coverArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop&q=80',
    milestone: 'diamond',
    threshold: 500,
    scrobblesEarned: 524,
    awardedDate: 'Jun 2026',
    frameStyle: 'obsidian',
    customEngraving: 'Diamond Disc of Honor commemorating supreme crate-digging dedication and over 500 plays.',
  },
];
