import React from 'react';
import { useMusic } from '../context/MusicContext';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { SAMPLE_PRESETS } from '../utils/sampleData';
import {
  Disc3,
  Radio,
  UploadCloud,
  Award,
  Sliders,
  Sparkles,
  Layers,
  ChevronDown,
  Clock,
  Database,
  User,
  Trophy,
  Cloud,
  CloudCheck,
  RefreshCw,
} from 'lucide-react';

interface NavbarProps {
  onOpenUpload: () => void;
  onOpenSync: () => void;
  onOpenCustomizer: () => void;
  onOpenPlaqueCreator: () => void;
  onOpenMilestones: () => void;
  onOpenAccount: () => void;
  onOpenCloudSyncProcess?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenUpload,
  onOpenSync,
  onOpenCustomizer,
  onOpenPlaqueCreator,
  onOpenMilestones,
  onOpenAccount,
  onOpenCloudSyncProcess,
}) => {
  const { user } = useAuth();
  const {
    activeUsername,
    lastfmUsername,
    activePresetId,
    loadPreset,
    allProcessedScrobbles,
    timeRange,
    setTimeRange,
    weeklyArtistsChart,
    artistsChart,
    openArtistProfile,
    isCloudSynced,
    isCloudSyncing,
  } = useMusic();
  const { theme } = useTheme();

  const defaultTopArtist = weeklyArtistsChart[0]?.artist || artistsChart[0]?.artist || 'Kavinsky';

  return (
    <header
      id="main-navbar"
      className="sticky top-0 z-40 w-full border-b border-zinc-800/80 bg-zinc-950/85 backdrop-blur-md transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div
            className={`p-2.5 rounded-2xl bg-gradient-to-br ${theme.accentGradient} text-white shadow-lg flex items-center justify-center`}
          >
            <Disc3 className="w-5 h-5 animate-[spin_8s_linear_infinite]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-lg tracking-tight text-white font-mono lowercase">
                yourhot100
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 font-medium hidden sm:block">
              Music Charts, Analytics &amp; Commemorative Plaque Forge
            </p>
          </div>
        </div>

        {/* Center: Vault Source Switcher */}
        <div className="hidden md:flex items-center gap-2 bg-zinc-900/90 border border-zinc-800 rounded-full px-3 py-1.5 shadow-inner">
          <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-500 flex items-center gap-1">
            <Radio className="w-3 h-3 text-red-500" /> Vault Source:
          </span>
          <select
            value={activePresetId === 'custom' ? 'upload' : 'lastfm'}
            onChange={(e) => {
              if (e.target.value === 'sync' || e.target.value === 'lastfm') {
                onOpenSync();
              } else if (e.target.value === 'upload') {
                onOpenUpload();
              }
            }}
            className="bg-transparent text-xs font-semibold text-zinc-200 focus:outline-none cursor-pointer pr-1"
          >
            <option value="lastfm" className="bg-zinc-900 text-white font-semibold">
              Last.fm Vault (@{lastfmUsername || activeUsername || 'iammarcus3'})
            </option>
            <option value="upload" className="bg-zinc-900 text-sky-400 font-semibold">
              📁 Uploaded History ({activePresetId === 'custom' ? 'Active' : 'Import File'})
            </option>
            <option value="sync" className="bg-zinc-900 text-emerald-400 font-bold">
              + Connect / Sync Last.fm Account...
            </option>
          </select>
        </div>

        {/* Timeframe Selector Pill */}
        <div className="hidden lg:flex items-center bg-zinc-900 border border-zinc-800 rounded-xl p-1 gap-1">
          {(['7d', '30d', '90d', '365d', 'all'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setTimeRange(r)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all uppercase ${
                timeRange === r
                  ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {r === 'all' ? 'All' : r}
            </button>
          ))}
        </div>

        {/* Actions Group */}
        <div className="flex items-center gap-2">
          {/* Cloud Sync Process Diagnostic Trigger */}
          {onOpenCloudSyncProcess && (
            <button
              onClick={onOpenCloudSyncProcess}
              id="nav-cloud-sync-process-btn"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-indigo-950/70 hover:bg-indigo-900/80 text-indigo-300 border border-indigo-700/50 transition-all cursor-pointer shadow-sm"
              title="Inspect live Cloud Sync Process & Diagnostics"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isCloudSyncing ? 'animate-spin' : ''}`} />
              <span className="hidden xl:inline">Sync Process</span>
            </button>
          )}

          {/* Account / Cloud Sync Trigger */}
          <button
            onClick={onOpenAccount}
            id="nav-account-btn"
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 transition-all hover:border-purple-500/50 cursor-pointer"
            title="User Account & Cloud Database Storage"
          >
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt="Account"
                referrerPolicy="no-referrer"
                className="w-5 h-5 rounded-full object-cover border border-purple-500"
              />
            ) : (
              <div className="w-5 h-5 rounded-full bg-purple-600/30 text-purple-400 border border-purple-500/40 flex items-center justify-center text-[10px] font-black">
                {user?.email ? user.email[0].toUpperCase() : <Cloud className="w-3 h-3" />}
              </div>
            )}

            <span className="hidden sm:inline truncate max-w-[90px]">
              {user?.displayName?.split(' ')[0] || (user ? 'Account' : 'Cloud Sync')}
            </span>

            {/* Live Cloud Status Dot */}
            <span
              className={`w-2 h-2 rounded-full ${
                isCloudSyncing
                  ? 'bg-amber-400 animate-ping'
                  : user
                  ? 'bg-emerald-400'
                  : 'bg-zinc-500'
              }`}
              title={isCloudSyncing ? 'Syncing...' : user ? 'Cloud Synced' : 'Local Storage Mode'}
            />
          </button>

          {/* Milestones & Records Trigger */}
          <button
            onClick={onOpenMilestones}
            id="nav-milestones-btn"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all hover:border-amber-500/50 cursor-pointer"
            title="Browse All #1s, Milestones, Best Debuts & Records"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Milestones</span>
          </button>

          {/* Artist Archive / Profile Trigger */}
          <button
            onClick={() => openArtistProfile(defaultTopArtist)}
            id="nav-artist-profile-btn"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 transition-all hover:border-zinc-700 cursor-pointer"
            title="Browse Artist Profile & Full Chart History"
          >
            <User className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Artist Archive</span>
          </button>

          {/* Last.fm Sync Modal Trigger */}
          <button
            onClick={onOpenSync}
            id="nav-sync-btn"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 transition-all cursor-pointer"
            title="Connect Last.fm Account or load profiles"
          >
            <Radio className="w-3.5 h-3.5 text-red-400" />
            <span className="hidden sm:inline">Last.fm Sync</span>
          </button>

          {/* Upload History Trigger */}
          <button
            onClick={onOpenUpload}
            id="nav-upload-btn"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 transition-all cursor-pointer"
            title="Import Spotify JSON or Last.fm CSV"
          >
            <UploadCloud className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Import</span>
          </button>

          {/* Forge Plaque Button */}
          <button
            onClick={onOpenPlaqueCreator}
            id="nav-forge-plaque-btn"
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-black bg-gradient-to-r ${theme.accentGradient} text-white shadow-md hover:brightness-110 transition-all cursor-pointer`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Forge Plaque</span>
          </button>

          {/* Theme & Layout Customizer */}
          <button
            onClick={onOpenCustomizer}
            id="nav-customizer-btn"
            className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 transition-all cursor-pointer"
            title="Customize studio theme and widget layout"
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

