import React from 'react';
import { useMusic } from '../context/MusicContext';
import { useTheme } from '../context/ThemeContext';
import {
  X,
  Music,
  User,
  Disc,
  Award,
  Calendar,
  Sparkles,
  TrendingUp,
  Clock,
  ExternalLink,
} from 'lucide-react';

interface DetailDrawerProps {
  onAwardPlaque: (item: {
    title: string;
    subtitle: string;
    type: 'track' | 'artist' | 'album';
    scrobbles: number;
    coverArt?: string;
  }) => void;
}

export const DetailDrawer: React.FC<DetailDrawerProps> = ({ onAwardPlaque }) => {
  const { selectedDetailItem, setSelectedDetailItem, openArtistProfile } = useMusic();
  const { theme } = useTheme();

  if (!selectedDetailItem) return null;

  const { type, data } = selectedDetailItem;

  const title = type === 'track' ? data.title : type === 'artist' ? data.artist : data.title;
  const subtitle = type === 'track' ? data.artist : type === 'artist' ? 'Artist Profile' : data.artist;
  const artistName = type === 'artist' ? data.artist : data.artist;
  const plays = data.playCount;
  const coverArt = data.coverArt;

  // Next Milestone calculation
  let nextMilestone = 'Gold (50)';
  let target = 50;
  if (plays >= 500) {
    nextMilestone = 'Multi-Diamond';
    target = 1000;
  } else if (plays >= 250) {
    nextMilestone = 'Diamond (500)';
    target = 500;
  } else if (plays >= 100) {
    nextMilestone = 'Multi-Platinum (250)';
    target = 250;
  } else if (plays >= 50) {
    nextMilestone = 'Platinum (100)';
    target = 100;
  }
  const progressPercent = Math.min(100, Math.round((plays / target) * 100));

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm">
      <div
        id="detail-drawer"
        className="w-full max-w-md bg-zinc-950 border-l border-zinc-800 shadow-2xl h-full flex flex-col justify-between p-6 overflow-y-auto space-y-6"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
              {type} Analytics
            </span>
          </div>

          <button
            onClick={() => setSelectedDetailItem(null)}
            className="p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Hero Detail Card */}
        <div className="space-y-4 text-center">
          <div className="relative w-36 h-36 mx-auto rounded-2xl overflow-hidden bg-zinc-900 border-2 border-zinc-800 shadow-2xl">
            <img
              src={coverArt}
              alt={title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div>
            <h2 className="text-lg font-black text-white tracking-tight">{title}</h2>
            <p className="text-xs font-semibold text-zinc-400 mt-0.5">{subtitle}</p>
          </div>

          <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-400">Next Plaque Tier: {nextMilestone}</span>
              <span className="font-mono font-bold text-amber-400">{plays} / {target} plays</span>
            </div>
            <div className="h-2 w-full bg-zinc-950 rounded-full overflow-hidden border border-zinc-800">
              <div
                className={`h-full bg-gradient-to-r ${theme.accentGradient} rounded-full transition-all`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Top Tracks for Artist */}
        {type === 'artist' && data.topTracks && (
          <div className="space-y-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-zinc-400 block">
              Top Catalog Rotation
            </span>
            <div className="space-y-1.5">
              {data.topTracks.map((tr: any, idx: number) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded-xl bg-zinc-900/40 text-xs text-zinc-300 font-mono"
                >
                  <span className="truncate pr-2">{tr.title}</span>
                  <span className="text-zinc-500 flex-shrink-0">{tr.playCount} plays</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bottom Actions */}
        <div className="pt-4 border-t border-zinc-800 space-y-2">
          {artistName && (
            <button
              onClick={() => {
                openArtistProfile(artistName);
                setSelectedDetailItem(null);
              }}
              className="w-full py-2.5 rounded-xl text-xs font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 flex items-center justify-center gap-2 transition-all hover:border-zinc-700"
            >
              <User className="w-4 h-4 text-sky-400" />
              <span>View Full Artist Archive & Chart Records</span>
            </button>
          )}

          <button
            onClick={() => {
              onAwardPlaque({
                title,
                subtitle: type === 'artist' ? 'Career Artist Achievement' : subtitle,
                type,
                scrobbles: plays,
                coverArt,
              });
              setSelectedDetailItem(null);
            }}
            className={`w-full py-2.5 rounded-xl text-xs font-black bg-gradient-to-r ${theme.accentGradient} text-white shadow-lg hover:brightness-110 flex items-center justify-center gap-2 transition-all`}
          >
            <Award className="w-4 h-4" />
            <span>Forge Commemorative Plaque</span>
          </button>
        </div>
      </div>
    </div>
  );
};
